const TOTAL_PROVIDERS_PER_LEAD = 3;
const MAX_RETRIES = 3;

/**
 * Assigns exactly 3 providers to a lead.
 * Retries automatically up to MAX_RETRIES times on PostgreSQL serialization failure (40001).
 * All provider-service relationships are loaded from the database — no hardcoded pools.
 *
 * @param {number} leadId
 * @param {number} serviceId
 * @param {object} pool - pg Pool instance
 * @returns {Promise<number[]>} array of assigned provider IDs
 */
async function assignProviders(leadId, serviceId, pool) {
  let attempt = 0;

  while (attempt < MAX_RETRIES) {
    const client = await pool.connect();
    try {
      await client.query('BEGIN TRANSACTION ISOLATION LEVEL SERIALIZABLE');
      await client.query("SET LOCAL lock_timeout = '5s'");
      await client.query("SET LOCAL statement_timeout = '10s'");

      const result = await _doAssign(leadId, serviceId, client);
      await client.query('COMMIT');
      return result;

    } catch (err) {
      await client.query('ROLLBACK');

      if (err.code === '40001' && attempt < MAX_RETRIES - 1) {
        attempt++;
        const jitter = Math.floor(Math.random() * 80) + 20; // 20–100ms
        await new Promise(resolve => setTimeout(resolve, jitter));
        continue;
      }

      throw err;
    } finally {
      client.release();
    }
  }
}

async function _doAssign(leadId, serviceId, client) {
  // STEP 1: Lock allocation_state row FOR UPDATE — serialization point per service
  const lockResult = await client.query(
    `SELECT service_id, last_provider_index
     FROM allocation_state
     WHERE service_id = $1
     FOR UPDATE`,
    [serviceId]
  );

  if (lockResult.rows.length === 0) {
    throw new Error(`No allocation_state row for service_id ${serviceId}. Run seed.js.`);
  }

  const currentIndex = lockResult.rows[0].last_provider_index;

  // STEP 2: Load mandatory providers from DB
  const mandatoryResult = await client.query(
    `SELECT p.id, p.name, p.remaining_quota
     FROM provider_services ps
     JOIN providers p ON p.id = ps.provider_id
     WHERE ps.service_id = $1 AND ps.is_mandatory = TRUE
     ORDER BY ps.pool_order, p.id
     FOR UPDATE OF p`,
    [serviceId]
  );

  // STEP 3: Load additional pool from DB (non-mandatory, ordered by pool_order)
  const additionalResult = await client.query(
    `SELECT p.id, p.name, p.remaining_quota
     FROM provider_services ps
     JOIN providers p ON p.id = ps.provider_id
     WHERE ps.service_id = $1 AND ps.is_mandatory = FALSE
     ORDER BY ps.pool_order, p.id`,
    [serviceId]
  );

  const mandatoryProviders = mandatoryResult.rows;
  const additionalPool     = additionalResult.rows;

  if (mandatoryProviders.length === 0 && additionalPool.length === 0) {
    throw new Error(`No providers configured for service_id ${serviceId}. Run seed.js.`);
  }

  const mandatoryIds = mandatoryProviders.map(p => p.id);
  const additionalSlotsNeeded = TOTAL_PROVIDERS_PER_LEAD - mandatoryIds.length;

  if (additionalSlotsNeeded < 0) {
    throw new Error(`Service ${serviceId} has ${mandatoryIds.length} mandatory providers, which exceeds the limit of ${TOTAL_PROVIDERS_PER_LEAD}.`);
  }

  // STEP 4: Verify mandatory provider quotas
  for (const provider of mandatoryProviders) {
    if (provider.remaining_quota <= 0) {
      throw new Error(
        `Mandatory provider "${provider.name}" quota exhausted. ` +
        `Reset quotas via webhook before submitting new leads for service ${serviceId}.`
      );
    }
  }

  // STEP 5: Assign mandatory providers
  for (const provider of mandatoryProviders) {
    await client.query(
      `INSERT INTO lead_assignments (lead_id, provider_id) VALUES ($1, $2)`,
      [leadId, provider.id]
    );
    await client.query(
      `UPDATE providers
       SET assigned_count  = assigned_count  + 1,
           remaining_quota = remaining_quota - 1
       WHERE id = $1`,
      [provider.id]
    );
  }

  // STEP 6: Round-robin selection for additional slots — DB-driven index, skip exhausted
  const selectedAdditional = [];
  let index    = currentIndex;
  let attempts = 0;
  const maxAttempts = additionalPool.length * 2;

  while (selectedAdditional.length < additionalSlotsNeeded && attempts < maxAttempts) {
    const candidate = additionalPool[index % additionalPool.length];
    index++;
    attempts++;

    if (!candidate) continue;
    if (mandatoryIds.includes(candidate.id))                   continue;
    if (selectedAdditional.find(p => p.id === candidate.id))   continue;

    // Lock row FOR UPDATE and re-read quota to prevent race conditions
    const freshResult = await client.query(
      `SELECT id, remaining_quota FROM providers WHERE id = $1 FOR UPDATE`,
      [candidate.id]
    );

    if (freshResult.rows[0].remaining_quota <= 0) continue;

    selectedAdditional.push(candidate);
  }

  if (selectedAdditional.length < additionalSlotsNeeded) {
    throw new Error(
      `Cannot fill ${additionalSlotsNeeded} additional slot(s) for service ${serviceId}. ` +
      `Not enough providers with remaining quota. Reset quotas via webhook.`
    );
  }

  // STEP 7: Assign additional providers
  for (const provider of selectedAdditional) {
    await client.query(
      `INSERT INTO lead_assignments (lead_id, provider_id) VALUES ($1, $2)`,
      [leadId, provider.id]
    );
    await client.query(
      `UPDATE providers
       SET assigned_count  = assigned_count  + 1,
           remaining_quota = remaining_quota - 1
       WHERE id = $1`,
      [provider.id]
    );
  }

  // STEP 8: Persist advanced round-robin pointer to DB
  const newIndex = additionalPool.length > 0 ? index % additionalPool.length : 0;
  await client.query(
    `UPDATE allocation_state
     SET last_provider_index = $1,
         updated_at          = NOW()
     WHERE service_id = $2`,
    [newIndex, serviceId]
  );

  return [...mandatoryIds, ...selectedAdditional.map(p => p.id)];
}

module.exports = { assignProviders };
