require('dotenv').config();

/**
 * Middleware to authenticate requests using a Bearer token.
 * Compares token against the ADMIN_TOKEN environment variable.
 */
function checkAdminToken(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader) {
    return res.status(401).json({ error: 'Authorization header is missing.' });
  }

  const parts = authHeader.split(' ');
  if (parts.length !== 2 || parts[0] !== 'Bearer') {
    return res.status(401).json({ error: 'Invalid Authorization header format. Must be Bearer <token>' });
  }

  const token = parts[1];
  const expectedToken = process.env.ADMIN_TOKEN;

  if (!expectedToken) {
    console.error('Warning: ADMIN_TOKEN environment variable is not set.');
    return res.status(500).json({ error: 'Server authentication is temporarily unconfigured.' });
  }

  if (token !== expectedToken) {
    return res.status(403).json({ error: 'Forbidden: Invalid administrative token.' });
  }

  next();
}

module.exports = checkAdminToken;
