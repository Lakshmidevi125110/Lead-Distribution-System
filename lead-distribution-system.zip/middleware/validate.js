const { z } = require('zod');

// Schema for customer lead submissions
const leadSchema = z.object({
  name: z.string().min(1, 'Name is required').max(255, 'Name cannot exceed 255 characters'),
  phone: z.string()
    .min(1, 'Phone is required')
    .max(20, 'Phone cannot exceed 20 characters')
    .regex(/^\+?[0-9\s\-()]+$/, 'Invalid phone format'),
  city: z.string().min(1, 'City is required').max(100, 'City cannot exceed 100 characters'),
  service_id: z.coerce.number().int().min(1, 'Service ID must be between 1 and 3').max(3, 'Service ID must be between 1 and 3'),
  description: z.string().max(1000, 'Description cannot exceed 1000 characters').optional().or(z.literal(''))
});

// Schema for incoming webhooks
const webhookSchema = z.object({
  event_id: z.string().min(1, 'Event ID is required').max(255, 'Event ID cannot exceed 255 characters'),
  event_type: z.enum(['quota_reset'], {
    errorMap: () => ({ message: "Only 'quota_reset' event type is supported" })
  }),
  payload: z.object({}).catchall(z.any()).optional()
});

/**
 * Validates request body using Zod schemas and returns formatted error messages.
 */
function validateLead(req, res, next) {
  const result = leadSchema.safeParse(req.body);
  if (!result.success) {
    return res.status(400).json({
      error: 'Validation failed',
      details: result.error.flatten().fieldErrors
    });
  }
  // Replace body with validated/coerced values
  req.body = result.data;
  next();
}

function validateWebhook(req, res, next) {
  const result = webhookSchema.safeParse(req.body);
  if (!result.success) {
    return res.status(400).json({
      error: 'Validation failed',
      details: result.error.flatten().fieldErrors
    });
  }
  req.body = result.data;
  next();
}

module.exports = {
  validateLead,
  validateWebhook
};
